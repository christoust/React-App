export const addCertification = (certification) => {
    return {
      type: 'ADD_CERTIFICATION',
      payload: {certification},
    };
  };
  