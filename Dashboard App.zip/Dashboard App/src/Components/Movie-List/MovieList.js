import React from 'react';
// import MovieItem from '../Movie-Item/MovieItem';
import './MovieList.css';
import moviesData from './movies.json';

const MovieList = ({ onMovieSelect }) => {
  return (
    <div className="movie-list">
      <h2 className='head'>Movie List</h2>
      <ul>
        {moviesData.map((movie) => (
          <li key={movie.id} onClick={() => onMovieSelect(movie)}>
            {movie.name}
          </li>
        ))}
      </ul>
    </div>
  );
};
export default MovieList;
