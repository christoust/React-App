import React, { useState } from 'react';
import AuthService from '../Authentication/AuthService';
import './signup.css';
// import { useNavigate } from 'react-router-dom';

const SignupForm = () => {
  // const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSignup = (e) => {
    e.preventDefault();
    const { email, password, confirmPassword } = formData;
    if (password.length < 8) {
      setError('Password must be at least 8 characters long');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    const isSignedUp = AuthService.signup(email, password);
    if (isSignedUp) {
      setError('');
      setFormData({
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
      });
      alert('Signup successful. Please login.');
      // navigate('/home'); 
    } else {
      setError('User already exists.');
    }
  };

  return (
    <div className='signup-container'>
      <h2>Signup</h2>
      <form onSubmit={handleSignup}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          onChange={handleChange}
          required
        />
        <button type="submit">Signup</button>
      </form>
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default SignupForm;
