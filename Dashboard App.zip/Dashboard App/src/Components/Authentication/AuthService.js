const AuthService = {
    users: [],
    currentUser: null,
  
    signup(email, password) {
      console.log(this.users);
      const existingUser = this.users.find((user) => user.email === email);
      if (existingUser) {
        return false; // User already exists
      }
  
      this.users.push({ email, password });
      return true;
    },
  
    login(email, password) {
      const user = this.users.find((user) => user.email === email && user.password === password);
      if (user) {
        this.currentUser = user;
        console.log("true");
        return true;

      } else {
        return false;
      }
    },
  
    logout() {
      this.currentUser = null;
    },
  
    getCurrentUser() {
      return this.currentUser;
    },
  };
  
  export default AuthService;
  