import React, { useState, useEffect } from 'react';
import MovieList from '../Movie-List/MovieList';
import './styles.css';

// import './styles.css'; // Import your CSS file (optional)

const Main = () => {
  const [movies, setMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);

  useEffect(() => {
    fetch('main/movies.json') 
    
    // Assuming the JSON file is in the 'src' directory
      .then((response) => response.json())
      .then((data) => setMovies(data));
  }, []);

  const handleMovieClick = (movie) => {
    setSelectedMovie(movie);
  };

  return (
    <div className="main-container">
      <MovieList movies={movies} onMovieClick={handleMovieClick} />
      {selectedMovie && (
        <div className="movie-details">
          <h2>{selectedMovie.name}</h2>
          <p>{selectedMovie.description}</p>
          <p>Director: {selectedMovie.director}</p>
          <p>Cast: {selectedMovie.cast.join(', ')}</p>
          <p>Genre: {selectedMovie.genre}</p>
        </div>
      )}
    </div>
  );
};

export default Main;
