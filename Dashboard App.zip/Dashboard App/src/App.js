import React, { useState } from 'react';
import './App.css';
// import AuthService from './Components/Authentication/AuthService';
import SignupForm from './Components/Signup/Signup';
import LoginForm from './Components/Login/loginForm';
import MovieList from './Components/Movie-List/MovieList';
import MovieItem from './Components/Movie-Item/MovieItem';
// import movies from './Components/Movie-List/movies.json'
// import Main from './Components/Main/main';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedMovie, setSelectedMovie] = useState(null);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  // const handleLogout = () => {
  //   AuthService.logout();
  //   setIsLoggedIn(false);
  // };

  const handleMovieSelect = (movie) => {
    console.log(movie);
    setSelectedMovie(movie);

  };

  return (
    <div className="App">
      {isLoggedIn ? (
        <>
          
          <div className="movie-catalogue">
            <MovieList onMovieSelect={handleMovieSelect} />
            
            {selectedMovie && <MovieItem movie={selectedMovie} />}
          </div>
        </>
      ) : (
        <>
          <SignupForm />
          <LoginForm onLogin={handleLogin} />
        </>
      )}
    </div>
  );
}

export default App;


  