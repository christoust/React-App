import React from 'react';

function Registration() {
  return (
    <div>
      <h2>Registration Page</h2>
    </div>
  );
}

export default Registration;