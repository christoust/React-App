// import logo from './logo.svg';
// import './App.css';
import LifecycleComponent from "./Component/LifeCycleComponent";

function App() {
  return (
    <LifecycleComponent newCount="10"/>
  );
}

export default App;
