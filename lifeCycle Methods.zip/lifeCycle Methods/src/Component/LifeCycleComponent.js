import React, { Component } from 'react';
import Child from './Child'

class LifecycleComponent extends Component {
  constructor(props) {
    super(props);
    this.state = { count: 0 ,show: true};
    console.log('Constructor');
  }

  static getDerivedStateFromProps(props) {
    console.log('getDerivedStateFromProps');
    return {count: props.newCount};
  }

  componentDidMount() {
    setTimeout(()=>{
        this.setState({count: 25})
    },1000)
    console.log('ComponentDidMount');
  }

  shouldComponentUpdate() {
    console.log('shouldComponentUpdate');
    return true;
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('Count before updating:', prevState.count);
    return null;
  }

  componentDidUpdate(prevProps, prevState) {
    console.log('Updated count:', this.state.count);
  }

  componentWillUnmount() {
    console.log('componentWillUnmount');
  }

  handleClick = () => {
    this.setState({ count: this.state.count + 1 });
  };

  delHeader=()=>
  {
    this.setState({show: false});
  }

  render() {
    let myheader;
    if(this.state.show)
    {
        myheader=<Child/>
    }
    console.log('Render');
    return (
      <div>
        {myheader}
        <button onClick={this.delHeader}>Delete Header</button>
        <h1>Count: {this.state.count}</h1>
        <button onClick={this.handleClick}>Increment</button>
        <div className="div1"></div>
        <div className="div2"></div>
      </div>
    );
  }
}

export default LifecycleComponent;
