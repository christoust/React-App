import React from 'react';
import './MovieList.css';
import moviesData from './movies.json';

const MovieList = ({ onMovieSelect }) => {
  return (
    <div className="movie-list">
      <h2>Movie List</h2>
      <ul>
        {moviesData.map((movie) => (
          <li  onClick={() => onMovieSelect(movie)}>
            {movie.name}
          </li>
        ))}
      </ul>
    </div>
  );
};
export default MovieList;
