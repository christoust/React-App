import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginForm from '../Login/loginForm';
import SignupForm from '../Signup/Signup';
// import Home from './Components/Home'; // Assuming you have a Home component

const AppRouter = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" component={LoginForm} />
        <Route path="/signup" component={SignupForm} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
