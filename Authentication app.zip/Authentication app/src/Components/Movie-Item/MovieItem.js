import React from "react";
import './MovieItem.css';


const MovieItem = ({ movie }) => {
  if (!movie) {
    return <div>Please select a movie</div>;
  }
  const { name, image, description, director, cast, genre } = movie;
  return (
    <div className="movie-item">
      <h2>{name}</h2>
      <img src={image} alt={name} />
      
      <p>{description}</p>
      <p><strong>Director:</strong> {director}</p>
      {cast && <p><strong>Cast:</strong> {cast.join(', ')}</p>}
      <p><strong>Genre:</strong> {genre}</p>
    </div>
  );
};


export default MovieItem;