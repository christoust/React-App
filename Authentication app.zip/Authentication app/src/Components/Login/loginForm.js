import React, { useState } from 'react';
import AuthService from '../Authentication/AuthService';
import './loginForm.css'
import { useNavigate,Link } from 'react-router-dom';
const LoginForm = ({ onLogin }) => {
  const navigate=useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const { email, password } = formData;
    const isAuthenticated = AuthService.login(email, password);
    if (isAuthenticated) {
        console.log("hello");
      onLogin();
      navigate("/dashboard");
    } else {
      setError('Invalid email or password');
    }
  };

  return (
    <div className='login-container'>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <button type="submit">Login</button>
      </form>
      {error && <p className="error">{error}</p>}
      <Link to= '/registration'> Sign Up? </Link>

    </div>
  );
};

export default LoginForm;
