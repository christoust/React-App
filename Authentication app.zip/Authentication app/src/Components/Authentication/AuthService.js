const AuthService = {
  users: JSON.parse(localStorage.getItem('users')) || [],

  saveUsersToLocalStorage() {
    localStorage.setItem('users', JSON.stringify(this.users));
  },



  signup(email, password) {
    const existingUser = this.users.find((user) => user.email === email);
    if (existingUser) {
      return false; 
    }

    this.users.push({ email, password });
    this.saveUsersToLocalStorage();
    return true;
  },

  login(email, password) {
    const user = this.users.find((user) => user.email === email && user.password === password);
    if (user) {
      return true;
    } else {
      return false;
    }
  },

  
};

export default AuthService;
