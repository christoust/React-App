import React from 'react';
import Product from '../Product/Product';
import productsData from './Products.json'; 
import '../Product/Product.css'

function ProductList()  {
  return (
    <div className="product-list">
      {productsData.map(product => (
        <Product
          key={product.title}
          title={product.title}
          type={product.type}
          description={product.description}
          url={product.url}
          price={product.price}
          rating={product.rating}
        />
      ))}
    </div>
  );
};

export default ProductList;
