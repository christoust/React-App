import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route,Navigate } from 'react-router-dom';

import SignupForm from './Components/Signup/Signup';
import LoginForm from './Components/Login/loginForm';
import MovieList from './Components/Movie-List/MovieList';
import MovieItem from './Components/Movie-Item/MovieItem';
import MainApp from './Components/Main/Main';

function App() {
  const [selectedMovie, setSelectedMovie] = useState(null);
    const [isLoggedIn, setIsLoggedIn] = useState(false);


  const handleMovieSelect = (movie) => {
    setSelectedMovie(movie);
  };

  const handleLogin = () => {
        setIsLoggedIn(true);
      };

  return (
    <Router>
      <div className='movie-catalogue'>
        <Routes>
          <Route path="/" element={<LoginForm onLogin={handleLogin}/>} />
          <Route
            path="/dashboard"
            element={
              isLoggedIn?(

              // <div className='movie-list'>
              //   <MovieList onMovieSelect={handleMovieSelect} />
              // <div className='movie-details'>
              //   {selectedMovie && <MovieItem movie={selectedMovie} />}
              //   </div>
              // </div>
              <MainApp/>
               ) : (
                <Navigate to="/" />)
            }
          />
          <Route path="/registration" element={<SignupForm />} />
        </Routes>
      </div>
    </Router>
  );
}


export default App;

//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [selectedMovie, setSelectedMovie] = useState(null);

//   const handleLogin = () => {
//     setIsLoggedIn(true);
//   };

 
//   const handleMovieSelect = (movie) => {
//     console.log(movie);
//     setSelectedMovie(movie);

//   };

//   return (
//     <div className="App">
//       {isLoggedIn ? (
//         <>
          
//           <div className="movie-catalogue">
//             <MovieList onMovieSelect={handleMovieSelect} />
            
//             {selectedMovie && <MovieItem movie={selectedMovie} />}
//           </div>
//         </>
//       ) : (
//         <>
//           <SignupForm />
//           <LoginForm onLogin={handleLogin} />
          
//         </>
//       )}
//     </div>
//   );
// }

// export default App;


  