import './App.css'; // Import the CSS file if applicable
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Updated import for Routes
import Login from './Component/Login'; // Import the Login component

function Home() {
  return <div>Welcome to the Home Page!</div>;
}

function App() {
  return (
    <Router>
      <Routes>  {/* Replaced Switch with Routes for React Router v6 */}
        <Route path="/" exact element={<Login />} /> {/* Use element prop for JSX */}
        <Route path="/home" element={<Home />} />  {/* Use element prop for JSX */}
      </Routes>
    </Router>
  );
}

export default App;
