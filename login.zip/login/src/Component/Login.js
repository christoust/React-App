import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';


import "./Login.css";

function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isUsernameValid, setIsUsernameValid] = useState(true);
  const [isPasswordValid, setIsPasswordValid] = useState(true);

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
    setIsUsernameValid(validateUsername(event.target.value));
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
    setIsPasswordValid(validatePassword(event.target.value));
  };

  const validateUsername = (username) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username);
  };

  const validatePassword = (password) => {
    return /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
      password
    );
  };

  const isFormValid = () => {
    if(username!==""&& password!=="")
    {return isUsernameValid && isPasswordValid;}
    return false;
    
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (isFormValid()) {
      navigate('/home');    }
  };

  return (
    <div className="login">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <label>Username (Email)</label>
        <input
          type="email"
          value={username}
          onChange={handleUsernameChange}
          placeholder="Enter your email"
        />
        {!isUsernameValid && (
          <span style={{ color: "red" }}>Enter a valid emailid</span>
        )}
        <label>Password</label>
        <input
          type="password"
          value={password}
          onChange={handlePasswordChange}
          placeholder="Enter your password"
        />
        {!isPasswordValid && (
          <span style={{ color: "red" }}>Enter a valid password</span>
        )}

        <button type="submit" disabled={!isFormValid()}>
          Login
        </button>
      </form>
    </div>
  );
}

export default Login;
