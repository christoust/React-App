import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './style.css';

const CrudOps = () => {
  const [posts, setPosts] = useState([]);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostBody, setNewPostBody] = useState('');
  const [selectedPostId, setSelectedPostId] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/posts?_limit=5');
        setPosts(response.data);
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    };

    fetchData();
  }, []);

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedPostId) {
        // Update existing post
        const response = await axios.put(`https://jsonplaceholder.typicode.com/posts/${selectedPostId}`, {
          title: newPostTitle,
          body: newPostBody,
          userId: 1, // Hardcoded user ID for demo purposes
        });
        const updatedPost = response.data;
        setPosts(posts.map(post => post.id === selectedPostId ? updatedPost : post));
        setSelectedPostId(null);
      } else {
        // Create new post
        const response = await axios.post('https://jsonplaceholder.typicode.com/posts', {
          title: newPostTitle,
          body: newPostBody,
          userId: 1, // Hardcoded user ID for demo purposes
        });
        setPosts([...posts, response.data]);
      }
      setNewPostTitle('');
      setNewPostBody('');
    } catch (error) {
      console.error('Error creating/updating post:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`);
      setPosts(posts.filter(post => post.id !== id));
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  const handleEdit = (id, title, body) => {
    setSelectedPostId(id);
    setNewPostTitle(title);
    setNewPostBody(body);
  };

  return (
    <div className='CrudOps'>
      <h1>Posts</h1>
      <ul>
        {posts.map((post) => (
          <li key={post.id}>
            {post.title} - {post.body}
            <button onClick={() => handleEdit(post.id, post.title, post.body)}>Edit</button>
            <button onClick={() => handleDelete(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
      <h2>{selectedPostId ? 'Edit Post' : 'Create New Post'}</h2>
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          placeholder="Title"
          value={newPostTitle}
          onChange={(e) => setNewPostTitle(e.target.value)}
        />
        <textarea
          placeholder="Body"
          value={newPostBody}
          onChange={(e) => setNewPostBody(e.target.value)}
        />
        <button type="submit">{selectedPostId ? 'Update' : 'Submit'}</button>
        {selectedPostId && <button type="button" onClick={() => setSelectedPostId(null)}>Cancel</button>}
      </form>
    </div>
  );
};

export default CrudOps;
