import './App.css';
import CrudOps from './curdOps';

function App() {
  return (
    <CrudOps/>
  );
}

export default App;
