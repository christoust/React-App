import React from 'react';
import RegistrationForm from './Components/Registration'; 
function App() {
  return (
    <div>
          <RegistrationForm />
    </div>
  );
}

export default App;
