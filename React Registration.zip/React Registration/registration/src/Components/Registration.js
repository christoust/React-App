import React from "react";
import "./Registration.css";

function RegistrationForm() {
  return (
    <div className="reg">
      <h1>Registration Form </h1>
      <form>
        <input type="text" name="name" placeholder="Name" />
        <input type="email" name="email" placeholder="Email" />
        <input type="password" name="password" placeholder="Password" />
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
        />
        <input
          type="date"
          id="dob"
          name="dob"
          placeholder="Enter your DOB"
          required
        />
        <div className="gender-options">
          <label>
            <input type="radio" id="male" name="gender" value="male" required />
            Male
          </label>
          <label>
            <input
              type="radio"
              id="female"
              name="gender"
              value="female"
              required
            />
            Female
          </label>
          <label>
            <input
              type="radio"
              id="other"
              name="gender"
              value="other"
              required
            />
            Other
          </label>
        </div>
        <select id="nationality" name="nationality">
        <option value="" disabled selected>Select nationality</option>
          <option value="us" >United States</option>
          <option value="ca">Canada</option>
          <option value="uk">United Kingdom</option>
          <option value="fr">France</option>
        </select>

        <input type="textArea" name="address" placeholder="Address"></input>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default RegistrationForm;
