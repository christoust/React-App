import React, { useState, useRef } from 'react';

// Component using useState
const StateComponent = () => {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <h1>State Component</h1>
      <p>Count: {count}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};

// Component using useRef
const RefComponent = () => {
  const countRef = useRef(0);

  const increment = () => {
    countRef.current += 1;
    console.log('RefComponent count:', countRef.current);
  };

  return (
    <div>
      <h1>Ref Component</h1>
      <p>Count: {countRef.current}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};

// Difference between useRef and useState
// useRef allows you to persist values between renders without causing a re-render
// useState causes a re-render whenever the state value changes
// useRef is useful for storing mutable values that don't trigger a re-render
// useState is useful for storing values that should trigger a re-render when changed

const DifferenceBetweenHooks = () => (
  <div>
    <StateComponent />
    <RefComponent />
  </div>
);

export default DifferenceBetweenHooks;
