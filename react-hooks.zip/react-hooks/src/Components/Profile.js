import  { useContext, useEffect, useReducer } from 'react';
import { UserContext } from './UserContext';

const useProfileData = () => {
  const { username } = useContext(UserContext);

  const initialState = {
    loading: true,
    userData: null
  };

  const reducer = (state, action) => {
    switch (action.type) {
      case 'FETCH_SUCCESS':
        return {
          loading: false,
          userData: action.payload
        };
      case 'FETCH_ERROR':
        return {
          loading: false,
          userData: null
        };
      default:
        return state;
    }
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://run.mocky.io/v3/3a89bccb-b746-4103-854e-88dd669546a2');
        const data = await response.json();
        dispatch({ type: 'FETCH_SUCCESS', payload: data });
      } catch (error) {
        console.error('Error fetching data:', error);
        dispatch({ type: 'FETCH_ERROR' });
      }
    };

    fetchData();
  }, []);

  return { username, ...state };
};

export default useProfileData;












// import React, { useContext } from 'react';
// import { UserContext } from './UserContext';

// const useProfileData = () => {
//   const { username } = useContext(UserContext);

//   const initialState = {
//     loading: true,
//     userData: null
//   };

//   const reducer = (state, action) => {
//     switch (action.type) {
//       case 'FETCH_SUCCESS':
//         return {
//           loading: false,
//           userData: action.payload
//         };
//       case 'FETCH_ERROR':
//         return {
//           loading: false,
//           userData: null
//         };
//       default:
//         return state;
//     }
//   };


//   const [state, dispatch] = useReducer(reducer, initialState);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await fetch('http://localhost:3001/');
//         const data = await response.json();
//         dispatch({ type: 'FETCH_SUCCESS', payload: data });
//       } catch (error) {
//         console.error('Error fetching data:', error);
//         dispatch({ type: 'FETCH_ERROR' });
//       }
//     };

//     fetchData();
//   }, []);

//   return { username, ...state };
// };

// const Profile = () => {
//   const { username, loading, userData } = useProfileData();

//   return (
//     <div>
//       {loading ? (
//         <p>Loading...</p>
//       ) : (
//         <div>
//           <h1>{username}'s Profile</h1>
//           <p>Name: {userData.name}</p>
//           <p>Country: {userData.country}</p>
//           <p>Gender: {userData.gender}</p>
//           <p>PAN: {userData.pan}</p>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Profile;
