import './App.css';
import RegisterFunction from './Components/Function/RegisterFunction';
import RegisterClass from './Components/Class/RegisterClass';
function App() {
  return (
  <><RegisterFunction /><RegisterClass /></>
    
  );
}

export default App;
