import React, { Component } from 'react';
import '../Function/RegisterFunction.css'
class RegisterClass extends Component {
    state = {
      name: '',
      age: '',
      company: '',
      submittedData: null
    };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    this.setState({ submittedData: { ...this.state } });
  };

  render() {
    const { name, age, company, submittedData } = this.state;

    return (
      <div className='reg'>
        <h1>Form usign Class Component</h1>
        <form onSubmit={this.handleSubmit}>
          <label>Name</label>
          <input
            type='text'
            name='name'
            value={name}
            onChange={this.handleChange}
            placeholder='Enter your name'
          />
          <label>Age</label>
          <input
            type='number'
            name='age'
            value={age}
            onChange={this.handleChange}
            placeholder='Enter your age'
          />
          <label>Company</label>
          <input
            type='text'
            name='company'
            value={company}
            onChange={this.handleChange}
            placeholder='Enter your company name'
          />
          <button type='submit'>Publish</button>
        </form>
        {submittedData && (
          <div className='submitted-data'>
            <h2>Submitted Data:</h2>
            <p>Name: {submittedData.name}</p>
            <p>Age: {submittedData.age}</p>
            <p>Company: {submittedData.company}</p>
          </div>
        )}
      </div>
    );
  }
}

export default RegisterClass;
